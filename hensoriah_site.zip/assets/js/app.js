
const state={products:[],cart:JSON.parse(localStorage.getItem('cart')||'[]'),search:''};
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
async function loadProducts(){const res=await fetch('data/products.json');state.products=await res.json();renderProducts();updateCartBadge();}
function renderProducts(){const grid=$('.grid');grid.innerHTML='';const q=state.search.toLowerCase();const items=state.products.filter(p=>!q||p.name.toLowerCase().includes(q)||p.tags.some(t=>t.includes(q)));for(const p of items){const card=document.createElement('article');card.className='card';card.innerHTML=`<img src="${p.image}" alt="${p.name}"><div class="content"><h3>${p.name}</h3><p class="price">${formatPrice(p.price,p.currency)}</p><p>${p.description}</p><div class="option-row">${Object.entries(p.options||{}).map(([label,vals])=>`<label>${label}: <select data-id="${p.id}" data-opt="${label}">${vals.map(v=>`<option>${v}</option>`).join('')}</select></label>`).join('')}</div><button class="buy" data-id="${p.id}">Add to cart</button></div>`;grid.appendChild(card);}}
function formatPrice(n,cur){return new Intl.NumberFormat(undefined,{style:'currency',currency:cur||'USD'}).format(n);}
function updateCartBadge(){const count=state.cart.reduce((a,b)=>a+b.qty,0);$('.cart-count').textContent=count;}
function currentSelections(id){const opts={};$$(`select[data-id="${id}"]`).forEach(el=>opts[el.getAttribute('data-opt')]=el.value);return opts;}
function addToCart(id){const product=state.products.find(p=>p.id===id);if(!product)return;const opts=currentSelections(id);const key=JSON.stringify({id,opts});const existing=state.cart.find(i=>JSON.stringify({id:i.id,opts:i.options})===key);if(existing){existing.qty+=1;}else{state.cart.push({id,name:product.name,price:product.price,currency:product.currency,image:product.image,options:opts,qty:1});}localStorage.setItem('cart',JSON.stringify(state.cart));updateCart();}
function updateCart(){updateCartBadge();const items=$('.cart .items');items.innerHTML='';for(const it of state.cart){const row=document.createElement('div');row.className='item';row.innerHTML=`<img src="${it.image}" alt="${it.name}"><div><strong>${it.name}</strong><div class="muted">${Object.entries(it.options||{}).map(([k,v])=>`${k}: ${v}`).join(', ')}</div><div>${formatPrice(it.price,it.currency)}</div></div><div><button class="qty minus" aria-label="Decrease">−</button><span class="qty-val">${it.qty}</span><button class="qty plus" aria-label="Increase">+</button><button class="remove" aria-label="Remove">✕</button></div>`;row.querySelector('.minus').onclick=()=>{it.qty=Math.max(1,it.qty-1);persist();};row.querySelector('.plus').onclick=()=>{it.qty=it.qty+1;persist();};row.querySelector('.remove').onclick=()=>{state.cart=state.cart.filter(x=>x!==it);persist();};items.appendChild(row);}const total=state.cart.reduce((sum,i)=>sum+i.price*i.qty,0);$('.cart .total .value').textContent=formatPrice(total,state.cart[0]?.currency||'USD');localStorage.setItem('cart',JSON.stringify(state.cart));}
function persist(){localStorage.setItem('cart',JSON.stringify(state.cart));updateCart();}
function openCart(show=true){$('.cart').classList.toggle('visible',show);}
function checkout(){const lines=state.cart.map(i=>`${i.name} x${i.qty} (${Object.entries(i.options||{}).map(([k,v])=>`${k}:${v}`).join(',')}) - ${formatPrice(i.price*i.qty,i.currency)}`);const total=state.cart.reduce((sum,i)=>sum+i.price*i.qty,0);const body=encodeURIComponent(`Order details:

${lines.join('
')}

Total: ${formatPrice(total,state.cart[0]?.currency||'USD')}

Shipping address:
`);const mailto=`mailto:hensoriahcreations@gmail.com?subject=New Order&body=${body}`;window.location.href=mailto;}
window.addEventListener('DOMContentLoaded',()=>{loadProducts();$('.nav input[type=search]').addEventListener('input',e=>{state.search=e.target.value;renderProducts();});document.body.addEventListener('click',e=>{const buy=e.target.closest('button.buy');if(buy){addToCart(buy.dataset.id);openCart(true);}const cartBtn=e.target.closest('.cart-btn');if(cartBtn){openCart();updateCart();}});$('.cart .actions .checkout').addEventListener('click',checkout);$('.cart .actions .clear').addEventListener('click',()=>{state.cart=[];persist();});});
